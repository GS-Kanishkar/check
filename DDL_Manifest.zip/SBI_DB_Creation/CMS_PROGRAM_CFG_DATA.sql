-- DEFINE schema_name = &1
DEFINE spool_path = &2
 
-- Change the output path as needed (relative or full path)
SPOOL &&spool_path/SPOOL_CMS_PROGRAM_CFG_DATA..sql
 
SET LONG 1000000
SET PAGESIZE 0
SET LINESIZE 200
SET FEEDBACK ON
SET ECHO ON
SET HEADING ON
SET TERMOUT OFF
SET TRIMSPOOL ON
--------------------------------------------------------
SET DEFINE OFF;

ALTER SESSION SET NLS_DATE_FORMAT = 'YYYY-MM-DD HH24:MI:SS';
ALTER SESSION SET NLS_TIMESTAMP_FORMAT = 'YYYY-MM-DD HH24:MI:SS';


ALTER SESSION SET CURRENT_SCHEMA = CMS_PROGRAM_CFG;

INSERT INTO institution (institution_id, account_end_date, account_start_date, address_line1, address_line2, address_line3, address_proof_type, branch_code_length, city_name, contact_number_desk1, contact_number_desk2, contact_person_name, country_name, currency_code, date_format_tc, email_address, facebook_profile, file_transfer_mode_tc, has_address_proof, has_authentication_module, has_authorization_module, has_hsm_racal, has_hsm_safenet, has_identity_proof, has_iso_switch, has_issuance_module, has_maker_checker, identity_proof_type, instagram_profile, institution_code, institution_name, is_switch_available, language_code, linkedin_profile, masking_character, max_virtual_card_count, max_physical_card_count, max_virtual_card_annual_count, max_virtual_card_daily_count, minor_max_age, minor_min_age, mobile_number, onboard_date, pin_length, pin_regeneration_gap, service_provider, state_name, status_tc, timezone_code, zip_code, region, approved_tc, approver_remarks, contact_one_isdcode, contact_two_isdcode, mobile_isdcode, send_renewal_to_cbs, refresh_card_number, autogenerate_program_code, program_code_length, card_count_validation, delete_comments, two_fa_required, default_channels_allowed, is_define_separate_channel_limit, is_define_aggregate_channel_limit, is_max_transactions_limit, is_card_count_restriction_required, is_captcha_required, np_card_variable, is_hsm_integration_required, is_card_upgrade_supported, is_program_hierarchy_required, has_card_reissuance_support, maximum_card_reissuance_time_period, maximum_card_reissuance_count, configure_wallet_account, fetch_communication_detail_from_cbs, generate_cbs_customer_id, default_card_limits, checked_by, checked_on, tenant_code, dml_type, dml_by, dml_on)  VALUES (1, '2099-12-31', '2025-05-02', 'SIPCOT IT Park, G4,1st cross street', 'Navalur Road, SH 49A, OMR', 'Siruseri, Navalur', NULL, 5, 'C00103', 'PV#', NULL, 'PV#', 'IND', 'INR', 'dd/mm/yyyy', 'fssadmin@gmail.com', NULL, 'Manual', NULL, 1, 0, NULL, NULL, NULL, 0, 0, 'Maker & Checker', NULL, NULL, 'FSS', 'Financial Software and Systems', NULL, 'English', NULL, '*', NULL, NULL, NULL, NULL, 18, 6, '9823617223', '2025-05-02', 1111, 1111, NULL, 'TN', 1, 'IST', '603103', 'India', 'A', NULL, '91', NULL, '91', 1, 1, 1, 7, NULL, NULL, 0, 'ECOMMERCE,ATM', 1, 1, 'Online', 0, 0, 'PV#', 1, 0, 0, 1111, NULL, NULL, 0, 1, 0, -1, 'System2', '2025-02-22 14:13:43', 'FSS', 'I', 'System1', '2025-02-22 14:13:43');

COMMIT;
SET DEFINE ON;

--------------------------------------------------------
SPOOL OFF
 
SET TERMOUT ON